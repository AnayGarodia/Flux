# Encoded
#### Video Demo:  <https://youtu.be/4YXSOz5dLTI>
#### Description:
    My project is a web application made with the help of Flask, SQLite3, HTML, and CSS. It serves as a password manager and
can store multiple accounts and passwords for multiple users in an encrypted way. As detailed in the CS50 Security Lecture, I
hope to make it easier for people to make complex and unique passwords as this will increase security and decrease data leaks.
It is very hard for a person to remember the number of passwords we need today thus, my website will provide a way for people
to store their information in an organized and safe way. My project consists of 4 static files, 8 templates, 1 database, 1
requirements file and 2 console files (application.py, helpers.py).
    In the static folder, the first file is "encoded_logo.png". It is an image that I designed that serves as the logo of the
website. The second is "icon.png" which serves as the icon which is to be displayed near the title. It is a shield as it
displays that the data is encrypted. The reason for not using the logo as the icon was that the logo has a great deal of
detail and thus would not look good at such a small resolution. Thirdly, there is "styles-layout.css" which lays out the basic styles
used throughout the program and lastly, there is "styles-register.css" which contains more styles used in all the templates.
    In the templates folder, I chose to use a modern and consistent design throughout the website. The website image used
throughout is a doodle (Credits: https://wallpapersafari.com/) which creates a nice aesthetic. In "layout.html", I used a
navigation bar similar to the "C$50 Finance" but added a few more styles. The website is pretty minimalist in its nature to
complements its modern design. In each of the html files with a form, there is an additional 'p' tag which is used to signify
errors similar to the "C$50 Finance's" apology function. I used this method as it creates a better experience for the user.
    The database of the project, "accounts.db", consists of four tables. The first table is called 'users' and consists of 4
columns. The first one is 'id' which is the primary key for the user. The second one is 'name' which holds the username of
the user. This information is stored using a custom encryption function which is detailed in the console. The third and fourth
are 'password' and 'email' respectively which stores the password and email of the user which is encrypted using werkzeug
security. The second table is called 'accounts' and also consists of four columns. The first column is called 'id' and is the
private key for each account. The second is called 'website' which stores the website name of the account. It is also
encrypted using the custom function. The third and fourth column consists of the 'username' and 'password' respectively which
stores the username and the password of that account. They are also encrypted using the custom function. The third table is
called 'user_accounts' and is a join table consisting of two foreign keys, "user-id' and "account-id", referencing users(id)
and accounts(id) respectively. The last table is called "contacts" and consists of two columns, "user_id" and "contact".
The "user_id" column is both a primary key and a foreign key (references users(id)). The "contact" column stores the feedback
by the user.
    The "requirements.txt" file consists of all the modules that are required in the console detailed later. It consists of 8
lines.
    Next, let's look at "helpers.py". It consists of 5 functions that are used in 'application.py'. The required functions are
in the 'requirements.txt'. The first function is 'login_required' which is borrowed from the "C$50 Finance's helpers.py" file
and is used to redirect to the 'login' page when the user has not logged in or in other words, the session is clear. The
second function is 'encrypt' which takes as input a string and returns an encrypted version of it using hexadecimal, binary
ascii, and some mathematical operations. I chose to use this instead of using the 'werkzeug.security' library as we cannot
decrypt a string that is encrypted with it but can only compare it with other strings. The third function is 'decrypt' which
takes as input a string encrypted by the 'encrypt' function detailed above and returns the original string. I tried to make
the encrypt function as convoluted as possible. The fourth function is the 'password_generator' which produces a random, 16
long password. Finally, there is 'strength_checker' which takes a string (a password) as input, performs some mathematics on
the string, and outputs the strength of the string in a scale of 0 to 10. 0 is awarded to those passwords who are very common
(25 most common passwords).
    Finally, let's take a look at 'application.py' which runs the entire backend of the web application and where all the
functions detailed in 'helpers.py' are used. The file starts by importing some modules (listed in requirements.txt), importing
the functions from 'helpers.py', linking the database, and configuring flask and flask_session. Next it sets a route for
"/register" which is where the user will be able to register for the website. If the website is requested via "GET", it loads
register.html. Else, it performs extensive error checking on the form submitted including requirements for the password
length, specific password digits, non-ascii letters in the password, etc. If any error condition is met, instead of using an
apology-like function as in "C$50 Finance", I wrote the error in red at the bottom of the form inside a 'p' tag. If the form
is proper, it inserts the information in the 'users' table in accounts.db and redirects the user to the index page. Next,
there is the 'login' route which lets a user who has already registered to log in. Similar to the '/register' route, it also
performs extensive error checking and redirects to index page if successful. The third route is the '/log-out' route which
lets the user to log out of their account. It performs this by clearing the session of the user and redirecting them to the
login page. The next route is "/" which provides the 'index.html' file with all the accounts of the user. This data is
processed to form a table which shows the user all his accounts and password. The next route is '/add-password' which lets
the user add an account. It does extensive error checking and if sucessful, inserts the encrypted version of the data in the
"accounts" table of 'accounts.db'. It then selects the id of that account and inserts it in the 'user_accounts' table. The
next route is "/generate-password" which generates a random password using the password_generator function from 'helpers.py'.
The next route is "/check-password-strength" which is used to check the strength of a password and does it using the
'strength-checker' function from 'helpers.py'. The last route is '/about' which provides the user with a platform to give
their feedback to me.
    The way to run the program is by typing 'flask run' in the command line as this is a flas-based web application.

