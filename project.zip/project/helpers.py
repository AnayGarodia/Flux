from string import digits, ascii_letters, punctuation
from random import randint
import os
import requests
import urllib.parse

from flask import redirect, render_template, request, session
from functools import wraps

def login_required(f):
    """
    Decorate routes to require login.

    https://flask.palletsprojects.com/en/1.1.x/patterns/viewdecorators/
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function

def encrypt(string):
     return_string = '#21@$^d'
     for i in range(len(string)):
          if string[i] == " ":
               n = "9999w"
          elif i % 3 == 0:
               n = hex(ord(string[i]) - 33)[2:] + "x"
               if len(n) == 1:
                    n = '0' + n
          elif i % 3 == 1:
               n = bin(ord(string[i]) - 33) [2:] + "y"
               if len(n) == 1:
                    n = '0' + n

          else:
               n = str(ord(string[i]) - 33) + "z"

          return_string += n

     return_string += return_string[:7]
     return return_string

def decrypt(string):
     string = list(string)
     result = []
     string = string[7:len(string)-7]

     while len(string) > 0:
          for char in range(len(string)):
               if string[char] == "w":
                    result.append(" ")
                    del string[:char+1]
                    break

               if string[char] == "x":
                    x = ''
                    for i in range( char):
                         x += string[i]
                    result.append(chr(int(x, 16) + 33))
                    del string[:char+1]
                    break

               if string[char] == "y":
                    x = ''
                    for i in range( char):
                         x += string[i]
                    result.append(chr(int(x, 2) + 33))
                    del string[:char+1]
                    break

               if string[char] == "z":
                    x = ''
                    for i in range( char):
                         x += string[i]
                    result.append(chr(int(x) + 33))
                    del string[:char+1]
                    break

     result_str = ''
     for n in result:
          result_str += n
     return result_str

def password_generator():
    charecters = list(digits) + list(ascii_letters) + list(punctuation)
    n = ''.join(charecters[randint(0, len(charecters) - 1)] for i in range(16))
    return n

def strength_checker(string):
    common = ["password", "123456", "12345678", "1234", "qwerty", "12345", "dragon", "football", "letmein", "monkey", "michael","mustang","abc123","696969","pussy", "baseball", "shadow", "master", "jennifer", "111111", "2000", "jordan", "superman", "harley", "1234567"]
    if string in common:
        return "0"
    score = len(string) * 2

    for i in string:
        if i.isnumeric() == True:
            score += 3
        elif i.isupper() == True:
            score += 2
        elif i.islower() == True:
            score += 1
        else:
            score += 4

    score = round(score/6)
    if score > 10:
        score = 10

    return score





