# Import required modules
import datetime
import os
from cs50 import SQL
from flask import Flask, render_template, request, session, redirect, flash
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from helpers import login_required, encrypt, decrypt, password_generator, strength_checker

# Link model
db = SQL("sqlite:///accounts.db")

# Initialize application
app = Flask(__name__)

# Initialize session
app.config["SESSION_PERMANENT"] = True
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Sets a route for registering
@app.route("/register", methods = ["GET", "POST"])
def register():

    # If website is requested, loads the register template
    if request.method == "GET":
        return render_template("register.html", error = '')

    # If form is submitted, does the following
    else:
        # If username is not entered, returns informing the same
        if not request.form.get("username"):
            return render_template("register.html", error = 'Please fill the username field')

        # If password is not entered, returns informing the same
        if not request.form.get("password"):
            return render_template("register.html", error = 'Please fill the password field')

        # If email is not entered, returns informing the same
        if not request.form.get("email"):
            return render_template("register.html", error = 'Please fill the email field')

        # If password is not confirmed, returns informing the same
        if not request.form.get("confirm_password"):
            return render_template("register.html", error = 'Please confirm the password')

        # Sets variables to the username, password, email and password confirmation
        username = request.form.get("username").strip()
        password = request.form.get("password").strip()
        email = request.form.get("email").strip()
        confirmation = request.form.get("confirm_password")

        # If length of password is less than 8, returns informing the same
        if len(password) < 8:
            return render_template("register.html", error = "The length of the password must be at least 8 charecters long")

        # Sets local variables marking uppercase, lowercase, digits and special charecters to 0
        up = 0
        down = 0
        special = 0
        digit = 0

        # For each letter in password, increments the specific variable and also filters non-ascii charecters
        for i in range(len(password)):
            if ord(password[i]) > 126:
                return render_template('register.html', error = 'Password cannot contain non-ascii charecters.')

            if password[i].isupper():
                up += 1
            elif password[i].islower():
                down += 1
            elif password[i].isdigit():
                digit += 1
            else:
                special += 1

        # For each letter in email filters non-ascii charecters.
        for i in range(len(email)):
            if ord(email[i]) > 126:
                return render_template('register.html', error = 'Email cannot contain non-ascii charecters.')

        # For each letter in username filters non-ascii charecters.
        for i in range(len(username)):
            if ord(username[i]) > 126:
                return render_template('register.html', error = 'Username cannot contain non-ascii charecters.')

        # If any of the local variables marking uppercase, lowercase, digits and special charecters is 0, returns informing the same
        if up == 0 or down == 0 or special == 0 or digit == 0:
            return render_template("register.html", error = 'Password must contain at least 1 uppercase, lowercase, number and special charecter.')

        # Selects all usernames in the database
        usernames = db.execute("SELECT name FROM users WHERE name = ?", encrypt(username))

        # If any previously registered username matches the one entered, returns informing the user of the same
        if len(usernames) > 0:
            return render_template("register.html", error = "A user with the same name already exists. Please try again.")

        # If the confirmed password does not match the password, returns informing the same
        if confirmation != password:
            return render_template("register.html", error = "Passwords do not match")

        # Generates username, password and email hash
        password_hash = generate_password_hash(password)
        email_hash = generate_password_hash(email)
        username_hash = encrypt(username)

        # Inserts the username, password and email into the database if all the previous error condititons are false.
        db.execute("INSERT INTO users(name, password, email) VALUES(?, ?, ?)", username_hash, password_hash, email_hash)

        # Gets the user id and stores it in the session.
        id_ = db.execute("SELECT id FROM users WHERE name = ?", encrypt(username))[0]["id"]
        session["user_id"] = id_

        return redirect("/")

# Sets a login  route
@app.route("/login", methods = ["GET", "POST"])
def login():

    # If the website is requested, loads the login template
    if request.method == "GET":
        return render_template("login.html", error = '')

    # If the username is not submitted, returns informing the same
    if not request.form.get("username"):
        return render_template("login.html", error = 'Please fill the username field.')

    # If the password is not submitted, returns informing the same
    if not request.form.get("password"):
        return render_template("login.html", error = 'Please fill the password field.')

    # Gets local variables to store the username and the password
    username = request.form.get("username").strip()
    password = request.form.get("password")

    # Gets all the names and passwords in the database with the same name as the username entered
    previous_usernames = db.execute("SELECT name FROM users WHERE name = ?", encrypt(username))
    previous_passwords_hash = db.execute("SELECT password FROM users WHERE name = ?", encrypt(username))

    print(previous_usernames)

    # If name is not in the database, returns saying the same
    if len(previous_usernames) != 1:
        return render_template("login.html", error = 'The username is incorrect')

    # Checks whether the entered password is correct
    if check_password_hash(previous_passwords_hash[0]["password"], password) == False:
        return render_template("login.html", error = 'The password is incorrect')

    # Stores the user id in a session if all is well
    user_id = db.execute("SELECT id FROM users WHERE name = ?", encrypt(username))[0]["id"]
    session["user_id"] = user_id

    # Redirects to home page
    return redirect("/")

# Creates a route to log out
@app.route("/log-out")
@login_required
def log_out():

    # Clears the session
    session.clear()

    # Redirects to login page
    return redirect("/login")

# Sets route for home page
@app.route("/")
@login_required
def index():
    # Gets the username with the user id stored in the session
    username = db.execute("SELECT name FROM users WHERE id = ?", session["user_id"])[0]["name"]

    # Gets the accounts of the user from the database
    accounts = db.execute("SELECT username, password, website FROM accounts WHERE id IN (SELECT account_id FROM user_accounts WHERE user_id = ?)", session["user_id"])

    # Stores all the decrypted versions of the usernames, passwords and websites in local variables
    usernames = []
    passwords = []
    websites = []
    for account in accounts:
        usernames.append(decrypt(account["username"]))
        passwords.append(decrypt(account["password"]))
        websites.append(decrypt(account["website"]))

    # Renders the index template
    return render_template("index.html", username = decrypt(username), usernames = usernames, passwords = passwords, websites = websites, length = len(usernames))

# Sets route for adding password
@app.route("/add-password", methods = ["GET", "POST"])
@login_required
def add():

    # Gets the username with the user id stored in the session
    user = db.execute("SELECT name FROM users WHERE id = ?", session["user_id"])[0]["name"]

    # If the website is requested, loads the correct template
    if request.method == "GET":

        return render_template("add-password.html", error = '', username = decrypt(user))

    # If username is not entered, returns informing the same
    if not request.form.get("username"):
        return render_template("add-password.html", error = "Please enter the username", username = decrypt(user))

    # If password is not entered, returns informing the same
    if not request.form.get("password"):
        return render_template("add-password.html", error = "Please enter the password", username = decrypt(user))

    # If username is not entered, returns informing the same
    if not request.form.get("website"):
        return render_template("add-password.html", error = "Please enter the website", username = decrypt(user))

    # Stores the username, password and website in local variables
    username = request.form.get("username")
    password = request.form.get("password")
    website = request.form.get("website")

    # Creates local variables which are encrypted versions of the username, password and website
    username_hash = encrypt(username)
    password_hash = encrypt(password)
    website_hash = encrypt(website)

    # Runs SQL queries for inserting the information into the database
    db.execute("INSERT INTO accounts(website, username, password) VALUES(?, ?, ?)", website_hash, username_hash, password_hash)
    acc_id = db.execute("SELECT id FROM accounts WHERE website = ? AND username = ? AND password = ?", website_hash, username_hash, password_hash)[0]["id"]
    db.execute("INSERT INTO user_accounts(user_id, account_id) VALUES(?, ?)", session["user_id"], acc_id)

    # Redirects to home page
    return redirect("/")

# Sets route for the password generator
@app.route("/generate-password", methods = ["GET", "POST"])
def generate():

    # Gets the username with the user id stored in the session
    user = db.execute("SELECT name FROM users WHERE id = ?", session["user_id"])[0]["name"]

    # If the website is requested, loads the correct template
    if request.method == "GET":

        return render_template("generate-password.html", password = '', username = decrypt(user))

    # Loads the template with the password
    return render_template("generate-password.html", password = password_generator(), username = decrypt(user))

# Sets route for the password strength checker
@app.route("/check-password-strength", methods = ["GET", "POST"])
def check_strength():

    # Gets the username with the user id stored in the session
    user = db.execute("SELECT name FROM users WHERE id = ?", session["user_id"])[0]["name"]

    # If website is requested, loads the correct template
    if request.method == "GET":
        return render_template("check-password-strength.html", result = '', username = decrypt(user))

    # If password is not entered, returns informing the same
    if not request.form.get("password"):
        return render_template("check-password-strength.html", result = 'Please fill the password field', username = decrypt(user))

    # Stores the password in a local variable
    password = request.form.get("password")

    # Stores the strength in a local variable
    strength = strength_checker(password)

    # Returns the template

    return render_template("check-password-strength.html", result = f'The strength of the password is {str(strength)}/10.', username = decrypt(user))

@app.route("/about", methods = ["GET", "POST"])
def about():
    # Gets the username with the user id stored in the session
    user = db.execute("SELECT name FROM users WHERE id = ?", session["user_id"])[0]["name"]

    # If website is requested, loads the correct template
    if request.method == "GET":
        return render_template("about.html", error = '', username = decrypt(user))

    # Checks whether the textarea is empty
    if not request.form.get("contact"):
        return render_template("about.html", error = 'Please fill the contact form', username = decrypt(user))

    # Stores the contact text in a local variable
    contact = request.form.get("contact")

    # If contact is the default text, returns informing the same
    if contact == "Your Feedback":
        return render_template("about.html", error = 'Please fill the contact form', username = decrypt(user))

    # Inserts data in database
    db.execute("INSERT INTO contacts(user_id, contact) VALUES(?, ?)", session["user_id"], contact)

    # Returns succesfully
    return render_template("about.html", error = 'Successfully submitted!', username = decrypt(user))